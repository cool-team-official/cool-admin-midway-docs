import { Plugin } from "../src/index";
import pluginInfo from "../plugin.json";

// 实例化插件
const indexInstance = new Plugin();
// 初始化插件
indexInstance.init(pluginInfo);

// 普通调用
indexInstance.invoke([{ role: "user", content: "你好" }]).then((res) => {
  console.log("普通调用", res.choices[0].message);
});

// 流式调用
indexInstance.invoke(
  [{ role: "user", content: "你好" }],
  {
    stream: true,
  },
  (data) => {
    console.log("流式调用", data);
  }
);
