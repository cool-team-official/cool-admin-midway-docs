import jwt from "jsonwebtoken";

/**
 * 生成token
 * @param apikey
 * @param expSeconds
 * @returns
 */
export const generateToken = (apikey, expSeconds) => {
  let [id, secret] = apikey.split(".");

  if (!id || !secret) {
    throw new Error("Invalid apikey");
  }

  const currentTimestamp = Math.floor(Date.now());
  const payload = {
    api_key: id,
    exp: currentTimestamp + expSeconds * 1000,
    timestamp: currentTimestamp,
  };

  const headers = {
    alg: "HS256",
    sign_type: "SIGN",
  };

  return jwt.sign(payload, secret, { algorithm: "HS256", header: headers });
};

/**
 * 解析流
 * @param stream
 * @param callback
 */
export const processData = (stream, callback: (data: any) => void) => {
  let buffer = "";
  // let isStreamFinished = false;

  stream.on("data", (data) => {
    buffer += data;
    // 循环处理所有完整的数据块
    let dataIndex;
    while ((dataIndex = buffer.indexOf("data: {")) !== -1) {
      // 查找下一个数据块的开始
      let nextDataIndex = buffer.indexOf("data: {", dataIndex + 1);
      if (nextDataIndex === -1) {
        nextDataIndex = buffer.indexOf("data: [DONE]");
      }
      let dataBlock = buffer
        .substring(
          dataIndex + 6,
          nextDataIndex !== -1 ? nextDataIndex : buffer.length
        )
        .trim();
      // 尝试解析当前数据块
      try {
        const dataObj = JSON.parse(dataBlock);
        const content = dataObj.choices
          .map((choice) => choice.delta.content)
          .join("");
        const isEnd = dataObj.choices.some((choice) => choice.finish_reason);

        callback({ content, isEnd, usage: isEnd ? dataObj.usage : null });
        // 准备处理下一个数据块
        buffer = nextDataIndex !== -1 ? buffer.substring(nextDataIndex) : "";
      } catch (e) {
        // 如果解析失败，等待更多数据
        break;
      }
    }
  });

  // stream.on("end", () => {
  //   // callback({ content: "", isEnd: true });
  // });
};
