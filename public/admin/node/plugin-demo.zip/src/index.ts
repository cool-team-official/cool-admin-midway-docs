import { BasePlugin } from "@cool-midway/plugin-cli";
import axios from "axios";
import * as utils from "./utils";

// 消息体
interface Message {
  // 角色
  role: "system" | "user" | "assistant";
  // 内容
  content: any;
}

/**
 * 智谱插件
 */
export class CoolPlugin extends BasePlugin {
  /**
   * 调用模型
   * @param messages 消息列表
   * @param options 配置，参考官方文档： https://open.bigmodel.cn/dev/api#glm-4
   * @param options callback 当stream为true时，回调函数
   * @returns 返回模型结果
   */
  async invoke(
    messages: Message[],
    options: any = {
      model: "glm-4",
      stream: false,
    },
    callback?: (data: any) => void
  ) {
    const { apiKey, baseUrl } = this.pluginInfo.config;
    // 合并配置
    options = {
      ...this.pluginInfo.config.options,
      ...options,
    };
    const { stream = false } = options;

    // 设置请求头
    const headers = {
      "Content-Type": "application/json;charset=UTF-8",
      Authorization: utils.generateToken(apiKey, 3600),
    };

    // 请求体
    const payload = {
      model: "glm-4",
      messages,
      ...options,
    };

    const reqConfig = {
      headers: headers,
      timeout: 120000, // 设置一个合适的超时时间
    };
    if (stream) reqConfig["responseType"] = "stream";

    const response = await axios.post(baseUrl, payload, reqConfig);
    return stream
      ? utils.processData(response.data, (e) => {
          if (e.isEnd) {
            callback({
              isEnd: true,
              usage: e.usage,
            });
          } else {
            callback({
              isEnd: false,
              content: e.content,
            });
          }
        })
      : response.data;
  }
}

// 导出插件实例， Plugin名称不可修改
export const Plugin = CoolPlugin;
