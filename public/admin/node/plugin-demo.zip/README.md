### 介绍

智谱 AI 大模型，开放平台官网：[https://open.bigmodel.cn/](https://open.bigmodel.cn/)，基于领先的千亿级多语言、多模态预训练模型，打造高效率、通用化的“模型即服务”AI 开发新范式。

插件提供了简单地调用智谱 AI 大模型的能力，可以通过插件的方式快速接入智谱 AI 大模型，实现智能化的功能。

### 标识

调用插件的时候需要用到标识，标识是唯一的，不能重复，建议使用英文，不要使用中文，对应插件 `plugin.json` 中的 `key` 字段

- 标识：zhipu

### 配置

```json
{
  "appId": "apiKey在智谱开放平台获得的APIKEY",
  "baseUrl": "调用地址",
  "options": {
    "model": "必须，所要调用的模型编码, 如：glm-4"
  }
}
```

完整的 options 配置可以参考文档：[https://open.bigmodel.cn/dev/api#glm-4](https://open.bigmodel.cn/dev/api#glm-4)

### 方法

下面是插件提供的一些方法

- invoke

```ts
 /**
   * 调用模型
   * @param messages 消息列表
   * @param options 配置，参考官方文档： https://open.bigmodel.cn/dev/api#glm-4
   * @param options callback 当stream为true时，回调函数
   * @returns 返回模型结果
   */
  async invoke(
    messages: Message[],
    options: any = {
      model: "glm-4",
      stream: false,
    },
    callback?: (data: any) => void
  )
```

消息体

```ts
// 消息体
interface Message {
  // 角色
  role: "system" | "user" | "assistant";
  // 内容
  content: any;
}
```

### 调用示例

```ts
@Inject()
pluginService: PluginService;

// 普通调用
await this.pluginService.invoke("zhipu",  "invoke", [{ role: "user", content: "你好" }]);

// 流式调用
await this.pluginService.invoke(
  "zhipu",
  "invoke",
  [{ role: "user", content: "你好" }],
  {
    stream: true,
  },
  (data) => {
    console.log(data);
  }
);
```

### 更新日志

- v1.0.0 (2024-01-29)
  - 初始版本
